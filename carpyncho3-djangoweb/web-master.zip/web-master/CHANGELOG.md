# CHANGELOG

## ver. 2019-07-24

- The nav bar now has a *loggin* button.
- The *about*, and *changelog* button is always available on the navbar.


## ver. 2019-06-22

- First version start.