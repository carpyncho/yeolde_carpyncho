from django.contrib import admin
from django.utils.translation import ugettext_lazy as _

from django.contrib.auth.admin import UserAdmin
from django.contrib.auth.models import User

from . import models as models

# =============================================================================
# TITLE
# =============================================================================

admin.site.site_header = _('Carpyncho Admin')

admin.site.site_title = _('Carpyncho Admin')

admin.site.index_title = _('Carpyncho Admin')


# =============================================================================
# TILES
# =============================================================================

class CatalogInline(admin.TabularInline):
    model = models.Catalog
    extra = 0


@admin.register(models.Tile)
class EventAdmin(admin.ModelAdmin):
    list_display = ("id", "name", "name", "row", "column", "size", "active")
    list_filter = ("row", "column", "active")
    ordering = ("name",)
    inlines = [CatalogInline]


# =============================================================================
# USERS
# =============================================================================

class UserProfileInline(admin.StackedInline):
    verbose_name_plural = "Profile"
    model = models.UserProfile


class TaskInline(admin.TabularInline):
    verbose_name_plural = "Tasks"
    model = models.Task
    extra = 0


class UserAdmin(UserAdmin):
    list_display = ('username', 'email', 'first_name', 'last_name')
    list_filter = ('is_staff', 'is_superuser')
    inlines = (UserProfileInline, TaskInline)


admin.site.unregister(User)
admin.site.register(User, UserAdmin)