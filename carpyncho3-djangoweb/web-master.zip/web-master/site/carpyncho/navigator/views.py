import os

from django.conf import settings

from django.shortcuts import render

from django.contrib.auth.mixins import LoginRequiredMixin
from django.views.generic.base import TemplateView
from django.db.models import Max

from django_downloadview import ObjectDownloadView

import numpy as np

import mistune

from . import models


# =============================================================================
# VIEWS
# =============================================================================

class TilesView(LoginRequiredMixin, TemplateView):

    template_name = "navigator/tiles.html"

    def get_context_data(self):
        tiles = models.Tile.objects.all()

        maxes = tiles.aggregate(Max("row"), Max("column"))
        rows = np.empty(
            (maxes["row__max"] + 1, maxes["column__max"] + 1), dtype=object)
        for tile in tiles:
            rows[tile.row][tile.column] = tile

        ctx = {"tiles": rows}
        return ctx


class UserView(LoginRequiredMixin, TemplateView):

    template_name = 'navigator/user.html'

    def get_context_data(self):
        return {"user": self.request.user}


# =============================================================================
# DOWNLOADS
# =============================================================================

class RegisterDownloadMixin:

    def get_extra_description(self):
        pass

    def norm_desc(self, description):
        return "\n".join([
            l.strip()
            for l in description.strip().splitlines()
            if l.strip()])

    def get(self, request, pk):
        user = request.user

        path = request.get_full_path_info()

        ip = (
            request.META.get("HTTP_X_FORWARDED_FOR") or
            request.META.get('REMOTE_ADDR'))

        extra_description = self.get_extra_description() or ""

        description = self.norm_desc(f"""
            - **User:** {user.username} ({user.email})
            - **Path:** `{path}`
            - **PK:** {pk}
            {extra_description}""")

        headers = dict(request.headers)

        models.Task.objects.create(
            user=user, ip=ip, description=description, headers=headers)

        return super().get(request=request, pk=pk)


class FeaturesObjectDownloadView(
    LoginRequiredMixin, RegisterDownloadMixin, ObjectDownloadView
):

    model = models.Tile
    file_field = 'features'

    def get_extra_description(self):
        tile = self.get_object()
        return f"""
            - **Tile:** {tile.name}"""


class CatalogsObjectDownloadView(
    LoginRequiredMixin, RegisterDownloadMixin, ObjectDownloadView
):

    model = models.Catalog
    file_field = 'data'

    def get_extra_description(self):
        cat = self.get_object()
        return f"""
            - **Tile:** {cat.tile.name}
            - **Catalog-Type:** {cat.catalog_type}"""


# =============================================================================
# MISC
# =============================================================================

class MarkdownClassMemoizeMixin:

    def load_md(self, path):
        with open(path) as fp:
            src = fp.read()
        return mistune.markdown(src)


class ChangesView(MarkdownClassMemoizeMixin, TemplateView):

    template_name = "navigator/changes.html"

    changelog_path = os.path.join(settings.COMMUNITY_FILES_DIR, "CHANGELOG.md")

    def get_context_data(self):
        return {"changelog": self.load_md(self.changelog_path)}


class AboutView(MarkdownClassMemoizeMixin, TemplateView):

    template_name = "navigator/about.html"

    readme_path = os.path.join(
        settings.COMMUNITY_FILES_DIR,  "README.md")
    license_path = os.path.join(
        settings.COMMUNITY_FILES_DIR,  "LICENSE")
    code_of_conduct_path = os.path.join(
        settings.COMMUNITY_FILES_DIR, "CODE_OF_CONDUCT.md")

    def get_context_data(self):
        return {
            "readme": self.load_md(self.readme_path),
            "license": self.load_md(self.license_path),
            "code_of_conduct": self.load_md(self.code_of_conduct_path)}