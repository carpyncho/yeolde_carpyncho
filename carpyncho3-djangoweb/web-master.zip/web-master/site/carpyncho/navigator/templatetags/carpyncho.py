
from django import template

# =============================================================================
# REGISTER
# =============================================================================

register = template.Library()


# =============================================================================
# FILTERS
# =============================================================================

CODES_2_BS4 = {
    0: "bg-success text-white",
    1: "bg-warning text-white",
    2: "bg-danger text-white",
    3: "bg-secondary text-white"
}

@register.filter(name='codeBS4')
def codeBS4(value):
    return CODES_2_BS4.get(value, "")