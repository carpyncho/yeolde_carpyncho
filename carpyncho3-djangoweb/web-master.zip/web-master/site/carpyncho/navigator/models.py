from django.db import models
from django.contrib.auth.models import User

from django_extensions.db.models import TimeStampedModel

from jsonfield import JSONField

import mistune

from model_utils.fields import StatusField
from model_utils import Choices


# =============================================================================
# TILE
# =============================================================================

def _features_upload_to(instance, filename):
    filename = f"feats_{filename}"
    return '/'.join(["tiles", instance.name, filename])


class Tile(TimeStampedModel):
    class Meta:
        unique_together = ('row', 'column')

    name = models.CharField(max_length=7, unique=True)
    active = models.BooleanField(default=False)

    row, column = models.PositiveIntegerField(), models.IntegerField()

    features = models.FileField(
        null=True, blank=True, upload_to=_features_upload_to)
    size = models.PositiveIntegerField(null=True, blank=True)


# =============================================================================
# CATALOG
# =============================================================================

def _catalog_upload_to(instance, filename):

    filename = f"cat_{instance.catalog_type}_{filename}"
    return "/".join(["tiles", instance.tile.name, filename])


class Catalog(TimeStampedModel):
    class Meta:
        unique_together = ('tile', 'catalog_type')

    CATALOG_TYPES = Choices(
        ("RRLyrae", "RR-Lyrae"))

    tile = models.ForeignKey(
        Tile, related_name="catalogs", on_delete=models.CASCADE)

    catalog_type = models.CharField(max_length=255, choices=CATALOG_TYPES)
    quality = models.FloatField()

    data = models.FileField(upload_to=_catalog_upload_to)
    size = models.PositiveIntegerField()



# =============================================================================
# USER PROFILE
# =============================================================================

class UserProfile(models.Model):

    user = models.OneToOneField(
        User, related_name="profile",
        on_delete=models.CASCADE, primary_key=True)

    affiliation = models.TextField()
    research_plan = models.TextField()

    def __str__(self):
        return str(self.user)


# =============================================================================
# TASKS
# =============================================================================

class Task(TimeStampedModel):

    user = models.ForeignKey(
        User, related_name="tasks", on_delete=models.CASCADE)
    ip = models.CharField(max_length=255, null=True)
    description = models.TextField()
    headers = JSONField(default=None)

    @property
    def html_description(self):
        return mistune.markdown(self.description)

    @property
    def oneline(self):
        return f"{self.id} - {self.created} - {self.ip}"

