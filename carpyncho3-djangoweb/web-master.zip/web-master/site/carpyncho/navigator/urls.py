from django.urls import path

from carpyncho.navigator import views


urlpatterns = [
    # =========================================================================
    # Default
    # =========================================================================

    path(
        '',
        views.TilesView.as_view(),
        name="home"),

    path(
        'tiles/',
        views.TilesView.as_view(),
        name="tiles"),

    path(
        'user/',
        views.UserView.as_view(),
        name="user"),

    # =========================================================================
    # DOWNLOADS
    # =========================================================================

    path(
        'features_download/<int:pk>',
        views.FeaturesObjectDownloadView.as_view(),
        name="features_download"),

    path(
        'catalog_download/<int:pk>',
        views.CatalogsObjectDownloadView.as_view(),
        name="catalog_download"),

    # =========================================================================
    # MISC
    # =========================================================================

    path(
        'about/',
        views.AboutView.as_view(),
        name='about'),


    path(
        'changes/',
        views.ChangesView.as_view(),
        name='changes')

]