
import os
import glob

from django.conf import settings
from django.core.management.base import BaseCommand
from django.core.management import call_command


class Command(BaseCommand):
    help = "Restore the database"

    def handle(self, *args, **options):
        for fd in settings.FIXTURES_DIRS:
            fglob = os.path.join(fd, "*.json")
            for file in  glob.glob(fglob):
                call_command("loaddata", file, verbosity=2)
